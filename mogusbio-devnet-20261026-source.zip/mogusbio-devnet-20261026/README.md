# BioLab

四类固定原料直接制造部件，玩家连接部件形成细胞、器官和生物。合成永久消耗本次投入的旧实例；合格成品质押后，按实际验证品质与当小时全网权重持续分配 LAB。

本目录是独立的新协议实现，未修改上层旧 MGUS 应用。实现含 Node 参考协议、独立 Rust/SBF 验证器、真实 SPL 经济/制造/结算程序、客户端与本地构造工作台。

```mermaid
flowchart LR
  A[玩家实验室发售四类原料] --> B[购买与真实库存]
  B --> C[固定原语部件]
  C --> D[自由连接与功能验证]
  D --> E[细胞]
  E --> F[器官]
  F --> G[生物]
  C --> S[成品质押]
  E --> S
  F --> S
  G --> S
  S --> H[闭合小时按权重结算 LAB]
  G --> K[严格更优且符合首创条件]
  K --> J[唯一首创额外权重]
  J --> H
```

## 运行与检查

要求 Node 22+。在本目录运行：

```sh
npm ci
npm test
node scripts/freeze-func2.mjs
npm start
```

工作台地址为 `http://127.0.0.1:4317/`，可设计、验证、比较和导出构造。
`npm run native:operator -- help` 提供原生交易的准备、检查、模拟、恢复和外部签名导入。
只有显式 `broadcast` 会发送。第四页“链上操作”依次准备、检查、模拟、签名、发送和查询恢复。第五页“资产与购买”可按真实发售记录规划购买，并按已知实例读取、规划普通质押/退出及历史补记/领取，再明确送入第四页检查。默认没有发布配置，钱包与交易操作保持关闭。第六至第八页接项目创建、库存制造和跨层合成；第九页接持续产出、完整退出与转让，第十页接私有承诺、候选轮次和Winner激活。
第十一页提供实验室发售目录及名称/完整ID/创建者搜索，第十二页按登录钱包分别发现当前成品、历史权益、原料ATA、Source和代币提示。可跨页选择有界ID集，交接后仍须明确重读。使用范围见[目录和钱包发现](docs/DISCOVERY-OPERATIONS.md)。
玩家完整流程见 [玩家指南](docs/PLAYER-GUIDE.md)；`position-plan` 规划个人补账/领取，
`keeper-plan` 规划全局事件和小时推进，也可明确选择关闭已完成小时并退还原开立者押存。

`test/player-lifecycle.test.mjs` 使用真实 FUNC2 与材料、合成、首创和结算模块，从购买开始走完60部件、15细胞、6器官和C320生物。System账户/PDA/rent采用明确的本地模型适配器；Rust验收单独验证真实签名权限、Token CPI、SBF预算和交易失败回滚，两者不相互冒充。

## 模块

| 模块 | 职责 |
| --- | --- |
| `packages/protocol-core` | 精确编码、固定目录、原子草稿、actor nonce、材料库存 |
| `packages/launchpad` | 玩家实验室发售、四类共享额度、购买与交付、Ops费用队列 |
| `packages/biology` | 结构、端口、容量、逐轮供能与控制、品质、H7、FUNC2证据 |
| `packages/composition` | Artifact、不可变历史胶囊、真实输入继承、单向合成与制造费用 |
| `packages/settlement` | 质押、冻结小时、独立历史计债、历史受益人、领取与守恒 |
| `packages/originality` | 公开种子、披露、承诺、候选、首创与有限错误证明 |
| `packages/client` | 材料/合成计划、官方SDK v1、外部钱包签名校验、显式发送、耐久日志与恢复 |
| `packages/bridge` | 服务端固定发布/RPC/私有日志，浏览器精确意图与 SDK 的受限桥接 |
| `programs/biolab-kernel` | 独立SBF数字功能内核及资源验收 |
| `programs/biolab-economy` | 原生发行/发售/Ops、部件与跨层合成、分步验证、ECON4持续结算、首创与有限错误证明 |
| `programs/transaction-transport` | 官方SDK签名、完整v1 Bank运输/收费验收 |
| `programs/provenance-probe` | 最大历史来源区间及普通SHA的SBF边界实测 |

## 已固定的含义

- AA、NUC、LIPID、SUGAR是四种不同底层原料类别。标准单位直接用于制造，没有开包、拆解或材料回收。
- 每个成品是独立资产。被合成消耗的旧实例不能继续质押；旧已赚未领权益仍归原受益人。
- 生物能是LAB的产品含义；数字模型中的E/FU/N不是额外可兑换代币。
- LAB总量一亿、6位小数。制造费来自玩家实际余额并销毁，不能凭空抵扣待赚收益。
- 每小时先冻结真实成员数、权重和预算，再按各成品自身历史计债；别人延迟计债不阻塞未来小时。每小时每个成品仍独立取整一次。
- 参考完整链使用 `[30,60,15,15]` 个四类标准原料单位，共120；制造费用按实际材料基数计算，完整链为48 LAB。器官费用分别计算，不能统一当作4 LAB。
- C320、C318、C316及本轮发现的C310均是公开知识，可普通持续产出，复制它们不具备首创额外奖励资格。新正式OPEN310保留16个必备模型，并增加C310为第17个公开K0，开场前沿为310。
- 首版是有限可验证的数字功能模型。不能据此宣称任意真实蛋白可折叠、活体可制造或生态世界已实现。

## 发布门禁

每份验收记录绑定其实际ELF、源码与测试范围。历史单模块通过不能代替最终合并程序通过。当前版本、模块结果、已修缺陷及上线门禁分别见 [实施状态](docs/IMPLEMENTATION-STATUS.md)、[最终复核](docs/FINAL-REVIEW.md) 与 [Solana验收](docs/solana-feasibility.md)。

公网多用户代码已补齐：消息签名登录、权限及会话隔离、HTTPS代理入口、页面控制器失效处理，以及有预算/耐久日志的持续服务。运行规格见[公网与服务手册](docs/PUBLIC-SERVICE-RUNBOOK.md)。新OPEN310同配置另完成23,709笔实际签名Bank交易，从空账本购料、制造、合成到普通质押、结算、领取、退出恢复及最终END；见[完整验收](programs/transaction-transport/OPEN310-FULL-LIFECYCLE-ACCEPTANCE.md)。旧475笔首创和805笔开场分支保留各自[证据范围](programs/transaction-transport/RESEARCH-BANK-ACCEPTANCE.md)。

本地交易控制台的配置和验收范围见 [P10.1 操作说明](docs/BROWSER-OPERATIONS.md)。
引导页范围与本地验收见 [P10.2a 操作说明](docs/GUIDED-OPERATIONS.md)。

一键本机体验见 [点击测试指南](docs/LOCAL-CLICK-PLAYTEST.md)；当前三个市场只作本地参考模型，正式原生市场与挂牌持续产出尚待实现。后续按 [模块积木与修改顺序](docs/MODULES-AND-CHANGE-GUIDE.md) 逐层变更、验收和保存版本；[本轮本地验收](docs/CLICK-PLAYTEST-ACCEPTANCE.md)固定实际范围。

主站与本地测试账号现采用七入口导航，项目首发与二级市场分开，工坊与生物能各自成页。见[导航结构](docs/PLAYER-NAVIGATION-PLAN.md)和[本轮导航验收](docs/PLAYER-NAVIGATION-ACCEPTANCE.md)。
